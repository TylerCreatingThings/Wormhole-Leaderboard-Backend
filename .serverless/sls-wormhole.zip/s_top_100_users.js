
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'tylerfarkas',
  applicationName: 'wormhole',
  appUid: 'HBJwDfWRtLz6MZFyCH',
  orgUid: '7e3a22db-fc39-4034-82f6-31e2594c9d44',
  deploymentUid: '73cd1d3e-0dae-4049-a142-b6346b7258e7',
  serviceName: 'sls-wormhole',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'sls-wormhole-dev-top-100-users', timeout: 30 };

try {
  const userHandler = require('./src/main/lambda-functions/top100Users/index.js');
  module.exports.handler = serverlessSDK.handler(userHandler.getTop100UsersHandler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}